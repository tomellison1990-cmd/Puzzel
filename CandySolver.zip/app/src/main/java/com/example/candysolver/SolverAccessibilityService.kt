package com.example.candysolver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Dispatches the swipe gestures that Solver decides on. Must be turned on
 * by the user from Settings > Accessibility -- Android will not let an app
 * enable this for itself.
 */
class SolverAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: SolverAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used: we only need gesture dispatch, not event/content inspection.
    }

    override fun onInterrupt() {}

    /**
     * Swipes from (x1,y1) to (x2,y2) in screen pixel coordinates.
     * onDone reports whether the gesture completed or was cancelled.
     */
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 180, onDone: (Boolean) -> Unit) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                onDone(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                onDone(false)
            }
        }, null)

        if (!dispatched) onDone(false)
    }
}
