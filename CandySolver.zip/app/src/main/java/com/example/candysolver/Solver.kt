package com.example.candysolver

data class Move(val r1: Int, val c1: Int, val r2: Int, val c2: Int)

/**
 * Brute-force match-3 move search. For a 9x9 board this evaluates roughly
 * 2 * rows * cols candidate swaps, each scored by simulating the swap and
 * counting resulting runs of length >= 3. This runs in well under a
 * millisecond on any modern phone, so it is never the bottleneck -- the
 * bottleneck is always screen capture + waiting for the game's animations.
 */
object Solver {

    fun findBestMove(grid: Array<IntArray>, rows: Int, cols: Int): Move? {
        var bestMove: Move? = null
        var bestScore = 0

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (c + 1 < cols) {
                    val score = trySwapScore(grid, r, c, r, c + 1)
                    if (score > bestScore) {
                        bestScore = score
                        bestMove = Move(r, c, r, c + 1)
                    }
                }
                if (r + 1 < rows) {
                    val score = trySwapScore(grid, r, c, r + 1, c)
                    if (score > bestScore) {
                        bestScore = score
                        bestMove = Move(r, c, r + 1, c)
                    }
                }
            }
        }
        return bestMove
    }

    private fun trySwapScore(grid: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int): Int {
        swap(grid, r1, c1, r2, c2)
        val score = countMatches(grid)
        swap(grid, r1, c1, r2, c2) // revert -- grid must be left untouched
        return score
    }

    private fun swap(grid: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int) {
        val tmp = grid[r1][c1]
        grid[r1][c1] = grid[r2][c2]
        grid[r2][c2] = tmp
    }

    /** Sum of (run length)^2 over every horizontal/vertical run of 3+ identical tiles. */
    private fun countMatches(grid: Array<IntArray>): Int {
        val rows = grid.size
        val cols = grid[0].size
        var score = 0

        for (r in 0 until rows) {
            var runLen = 1
            for (c in 1 until cols) {
                if (grid[r][c] == grid[r][c - 1] && grid[r][c] >= 0) {
                    runLen++
                } else {
                    if (runLen >= 3) score += runLen * runLen
                    runLen = 1
                }
            }
            if (runLen >= 3) score += runLen * runLen
        }

        for (c in 0 until cols) {
            var runLen = 1
            for (r in 1 until rows) {
                if (grid[r][c] == grid[r - 1][c] && grid[r][c] >= 0) {
                    runLen++
                } else {
                    if (runLen >= 3) score += runLen * runLen
                    runLen = 1
                }
            }
            if (runLen >= 3) score += runLen * runLen
        }
        return score
    }
}
