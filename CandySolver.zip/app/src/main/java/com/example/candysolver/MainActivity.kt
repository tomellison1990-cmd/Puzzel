package com.example.candysolver

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.candysolver.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, CaptureService::class.java).apply {
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, "Screen capture starting…", Toast.LENGTH_SHORT).show()
            }
            updateStatus()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Calibration.load(this)
        binding.editRows.setText(Calibration.rows.toString())
        binding.editCols.setText(Calibration.cols.toString())

        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnGrantCapture.setOnClickListener {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(mgr.createScreenCaptureIntent())
        }

        binding.btnCalibrate.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                Toast.makeText(this, "Grant \"draw over other apps\", then tap Calibrate again", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            Calibration.rows = binding.editRows.text.toString().toIntOrNull() ?: 9
            Calibration.cols = binding.editCols.text.toString().toIntOrNull() ?: 9
            Toast.makeText(this, "Switch to the game now — first tap sets the top-left tile", Toast.LENGTH_LONG).show()
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_CALIBRATE))
        }

        binding.btnStartStop.setOnClickListener {
            if (SolverLoop.isRunning) {
                SolverLoop.stop()
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_HIDE))
                binding.btnStartStop.text = getString(R.string.start_solving)
            } else {
                if (!Calibration.isSet) {
                    Toast.makeText(this, "Calibrate the grid first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (SolverAccessibilityService.instance == null) {
                    Toast.makeText(this, "Enable the Accessibility Service first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (CaptureService.getLatestFrame() == null) {
                    Toast.makeText(this, "Grant screen capture first", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                SolverLoop.statusListener = { msg -> runOnUiThread { binding.tvStatus.text = msg } }
                SolverLoop.start()
                startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_SHOW_CONTROL))
                binding.btnStartStop.text = getString(R.string.stop_solving)
                Toast.makeText(this, "Switch to the game — solving will run in the background", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val accOn = SolverAccessibilityService.instance != null
        val capOn = CaptureService.getLatestFrame() != null
        binding.tvStatus.text =
            "Accessibility: ${if (accOn) "ON" else "OFF"}  |  Capture: ${if (capOn) "ON" else "waiting"}  |  Calibrated: ${Calibration.isSet}"
    }
}
