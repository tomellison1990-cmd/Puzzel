package com.example.candysolver

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

data class BoardDetection(
    val left: Int, val top: Int, val right: Int, val bottom: Int,
    val rows: Int, val cols: Int
)

/**
 * Locates the game board automatically from a full-screen capture, instead of
 * requiring the user to precisely tap two tile corners by hand.
 *
 * How it works:
 *  1. Downscale the frame and compute a simple edge-energy map (how much
 *     color changes from each pixel to its neighbors). A grid of colorful
 *     tiles has far more local variation than the flatter UI chrome (score
 *     bars, buttons, plain backgrounds) around it.
 *  2. Average that energy per row, then per column, to find the screen's
 *     single busiest contiguous rectangle -- that's the board.
 *  3. Estimate the tile pitch inside that rectangle via autocorrelation of
 *     the same energy signal (tile borders recur at a constant spacing
 *     regardless of which candy occupies each cell, so this works even
 *     though individual tile colors aren't periodic). Board size / pitch
 *     gives rows and columns.
 *
 * This is a heuristic, not a guaranteed-correct detector -- it's deliberately
 * paired with a visual preview + adjustable row/col count + retry in
 * OverlayService rather than being trusted blindly.
 */
object GridDetector {

    private const val WORK_WIDTH = 360 // downscale target; plenty of resolution, stays fast

    fun detect(source: Bitmap): BoardDetection? {
        if (source.width < 10 || source.height < 10) return null

        val scale = WORK_WIDTH.toFloat() / source.width
        val workWidth = WORK_WIDTH
        val workHeight = (source.height * scale).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createScaledBitmap(source, workWidth, workHeight, true)

        val gray = IntArray(workWidth * workHeight)
        for (y in 0 until workHeight) {
            for (x in 0 until workWidth) {
                val p = bmp.getPixel(x, y)
                gray[y * workWidth + x] =
                    (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
            }
        }

        // Simple gradient-magnitude edge map: |dx| + |dy| per pixel.
        val edge = FloatArray(workWidth * workHeight)
        for (y in 0 until workHeight - 1) {
            for (x in 0 until workWidth - 1) {
                val here = gray[y * workWidth + x]
                val right = gray[y * workWidth + x + 1]
                val down = gray[(y + 1) * workWidth + x]
                edge[y * workWidth + x] = (abs(here - right) + abs(here - down)).toFloat()
            }
        }

        // Vertical extent of the busiest band.
        val rowActivity = FloatArray(workHeight)
        for (y in 0 until workHeight) {
            var sum = 0f
            for (x in 0 until workWidth) sum += edge[y * workWidth + x]
            rowActivity[y] = sum / workWidth
        }
        smooth(rowActivity, 3)
        val vBand = longestDenseRun(rowActivity) ?: return null
        val (topY, bottomY) = vBand

        // Horizontal extent, restricted to that vertical band.
        val colActivity = FloatArray(workWidth)
        for (x in 0 until workWidth) {
            var sum = 0f
            for (y in topY..bottomY) sum += edge[y * workWidth + x]
            colActivity[x] = sum / (bottomY - topY + 1)
        }
        smooth(colActivity, 3)
        val hBand = longestDenseRun(colActivity) ?: return null
        val (leftX, rightX) = hBand

        if (rightX - leftX < 20 || bottomY - topY < 20) return null // too small to be a real board

        val pitchX = estimatePitch(colActivity, leftX, rightX)
        val pitchY = estimatePitch(rowActivity, topY, bottomY)
        if (pitchX <= 0 || pitchY <= 0) return null

        val cols = Math.round((rightX - leftX) / pitchX.toFloat()).coerceIn(3, 20)
        val rows = Math.round((bottomY - topY) / pitchY.toFloat()).coerceIn(3, 20)

        val invScale = 1f / scale
        return BoardDetection(
            left = (leftX * invScale).toInt(),
            top = (topY * invScale).toInt(),
            right = (rightX * invScale).toInt(),
            bottom = (bottomY * invScale).toInt(),
            rows = rows,
            cols = cols
        )
    }

    private fun smooth(arr: FloatArray, radius: Int) {
        val copy = arr.copyOf()
        for (i in arr.indices) {
            var sum = 0f
            var count = 0
            for (d in -radius..radius) {
                val j = i + d
                if (j in arr.indices) { sum += copy[j]; count++ }
            }
            arr[i] = sum / count
        }
    }

    /** Longest contiguous run of indices where the signal sits clearly above background level. */
    private fun longestDenseRun(signal: FloatArray): Pair<Int, Int>? {
        if (signal.isEmpty()) return null
        val mean = signal.average().toFloat()
        var variance = 0f
        for (v in signal) variance += (v - mean) * (v - mean)
        val std = sqrt(variance / signal.size)
        val threshold = mean + std * 0.25f

        var bestStart = -1
        var bestEnd = -1
        var bestLen = 0
        var curStart = -1
        var gap = 0
        val maxGap = 4 // bridge small dips, e.g. thin grid-line borders between tiles

        for (i in signal.indices) {
            if (signal[i] >= threshold) {
                if (curStart == -1) curStart = i
                gap = 0
            } else if (curStart != -1) {
                gap++
                if (gap > maxGap) {
                    val end = i - gap
                    if (end - curStart > bestLen) { bestLen = end - curStart; bestStart = curStart; bestEnd = end }
                    curStart = -1
                    gap = 0
                }
            }
        }
        if (curStart != -1) {
            val end = signal.size - 1
            if (end - curStart > bestLen) { bestLen = end - curStart; bestStart = curStart; bestEnd = end }
        }
        return if (bestStart == -1) null else bestStart to bestEnd
    }

    /** Autocorrelation peak lag within [from, to) -- approximates tile pitch in downscaled px. */
    private fun estimatePitch(signal: FloatArray, from: Int, to: Int): Int {
        val len = to - from
        if (len < 12) return 0
        val segment = signal.copyOfRange(from, to)
        val minLag = max(6, len / 20)
        val maxLag = len / 2
        if (maxLag <= minLag) return 0

        var bestLag = 0
        var bestScore = Float.NEGATIVE_INFINITY
        for (lag in minLag..maxLag) {
            var sum = 0f
            var count = 0
            for (i in 0 until segment.size - lag) {
                sum += segment[i] * segment[i + lag]
                count++
            }
            if (count == 0) continue
            val score = sum / count
            if (score > bestScore) { bestScore = score; bestLag = lag }
        }
        return bestLag
    }
}
