package com.example.candysolver

import android.graphics.Bitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * The orchestration loop: wait for the board to stop animating, read it,
 * ask Solver for the best move, dispatch the swipe, repeat.
 *
 * "Fastest" mostly comes down to two things here, since the solve step
 * itself is sub-millisecond:
 *  1. Detecting "board is stable" as early as possible instead of a fixed
 *     sleep -- see waitForStableFrame().
 *  2. Keeping classification cheap -- see BoardAnalyzer (plain color
 *     averaging + sampling, no per-frame ML inference).
 */
object SolverLoop {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null

    var isRunning: Boolean = false
        private set

    var statusListener: ((String) -> Unit)? = null

    fun start() {
        if (isRunning) return
        isRunning = true
        job = scope.launch {
            while (isActive && isRunning) {
                val bitmap = waitForStableFrame()
                if (bitmap == null) {
                    delay(300)
                    continue
                }

                val grid = BoardAnalyzer.analyze(bitmap)
                val move = Solver.findBestMove(grid, Calibration.rows, Calibration.cols)

                if (move == null) {
                    statusListener?.invoke("No move found — stopping (board solved, or calibration is off)")
                    isRunning = false
                    break
                }

                val (x1, y1) = Calibration.cellCenter(move.r1, move.c1)
                val (x2, y2) = Calibration.cellCenter(move.r2, move.c2)
                statusListener?.invoke("Swiping (${move.r1},${move.c1}) -> (${move.r2},${move.c2})")

                performSwipe(x1, y1, x2, y2)
                delay(250) // give the game a moment to start its animation before we re-check stability
            }
        }
    }

    fun stop() {
        isRunning = false
        job?.cancel()
        statusListener?.invoke("Stopped")
    }

    /** Polls captured frames until two consecutive samples are near-identical, meaning animations have settled. */
    private suspend fun waitForStableFrame(): Bitmap? {
        var previous: Bitmap? = null
        repeat(20) { // ~4 seconds max before giving up on this cycle
            val current = CaptureService.getLatestFrame()
            if (current != null && previous != null && framesSimilar(previous!!, current)) {
                return current
            }
            previous = current
            delay(200)
        }
        return previous
    }

    private fun framesSimilar(a: Bitmap, b: Bitmap): Boolean {
        if (a.width != b.width || a.height != b.height) return false
        val stepX = maxOf(1, a.width / 40)
        val stepY = maxOf(1, a.height / 40)
        var diff = 0
        var total = 0
        var x = 0
        while (x < a.width) {
            var y = 0
            while (y < a.height) {
                total++
                if (a.getPixel(x, y) != b.getPixel(x, y)) diff++
                y += stepY
            }
            x += stepX
        }
        return total == 0 || diff.toDouble() / total < 0.01
    }

    private suspend fun performSwipe(x1: Int, y1: Int, x2: Int, y2: Int) = suspendCancellableCoroutine<Unit> { cont ->
        val svc = SolverAccessibilityService.instance
        if (svc == null) {
            if (cont.isActive) cont.resume(Unit)
            return@suspendCancellableCoroutine
        }
        svc.swipe(x1, y1, x2, y2) {
            if (cont.isActive) cont.resume(Unit)
        }
    }
}
