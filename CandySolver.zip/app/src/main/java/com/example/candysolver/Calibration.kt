package com.example.candysolver

import android.content.Context

/**
 * Stores the on-screen bounds of the game board plus the grid size.
 * Filled in by a two-tap calibration flow (top-left cell center, bottom-right
 * cell center) run from OverlayService, then persisted to SharedPreferences.
 */
object Calibration {
    var rows: Int = 9
    var cols: Int = 9
    var left: Int = 0
    var top: Int = 0
    var right: Int = 0
    var bottom: Int = 0

    val isSet: Boolean get() = right > left && bottom > top

    /** Smallest cell dimension in pixels, used to size the color-sampling patch. */
    fun cellSizePx(): Int {
        if (!isSet) return 0
        val cellW = (right - left) / cols
        val cellH = (bottom - top) / rows
        return minOf(cellW, cellH)
    }

    /** Center point of grid cell (row, col) in screen pixel coordinates. */
    fun cellCenter(row: Int, col: Int): Pair<Int, Int> {
        val cellW = (right - left).toFloat() / cols
        val cellH = (bottom - top).toFloat() / rows
        val x = (left + cellW * (col + 0.5f)).toInt()
        val y = (top + cellH * (row + 0.5f)).toInt()
        return x to y
    }

    private const val PREFS = "calibration_prefs"

    fun save(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("rows", rows)
            .putInt("cols", cols)
            .putInt("left", left)
            .putInt("top", top)
            .putInt("right", right)
            .putInt("bottom", bottom)
            .apply()
    }

    fun load(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        rows = p.getInt("rows", 9)
        cols = p.getInt("cols", 9)
        left = p.getInt("left", 0)
        top = p.getInt("top", 0)
        right = p.getInt("right", 0)
        bottom = p.getInt("bottom", 0)
    }
}
