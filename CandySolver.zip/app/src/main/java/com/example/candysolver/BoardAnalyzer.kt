package com.example.candysolver

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.sqrt

/**
 * Turns a screen bitmap into a grid of tile-type IDs.
 *
 * Approach: sample a small patch at the center of each cell (avoiding the
 * edges, where drop-shadow/border pixels live), average its color, then
 * greedily cluster the per-cell average colors across the whole board into
 * a handful of groups. This is a good match for classic candy-style tiles,
 * which are distinguished mainly by strong, distinct colors -- it is far
 * cheaper than running a shape classifier per frame and needs no ML model
 * or external CV library.
 *
 * If your target game distinguishes tiles primarily by shape/icon rather
 * than color (e.g. two candies share a color family), swap the sampling
 * step out for an edge/shape signature instead -- the rest of the pipeline
 * (clustering, Solver, SolverLoop) does not need to change.
 */
object BoardAnalyzer {

    fun analyze(bitmap: Bitmap): Array<IntArray> {
        val rows = Calibration.rows
        val cols = Calibration.cols
        val patch = maxOf(2, Calibration.cellSizePx() / 6)

        val samples = ArrayList<Triple<Int, Int, Int>>(rows * cols)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val (cx, cy) = Calibration.cellCenter(r, c)
                samples.add(averageColor(bitmap, cx, cy, patch))
            }
        }

        val labels = clusterColors(samples, maxClusters = 8, distanceThreshold = 36.0)

        val grid = Array(rows) { IntArray(cols) }
        var idx = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                grid[r][c] = labels[idx]
                idx++
            }
        }
        return grid
    }

    private fun averageColor(bitmap: Bitmap, cx: Int, cy: Int, radius: Int): Triple<Int, Int, Int> {
        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        var count = 0

        val startX = (cx - radius).coerceAtLeast(0)
        val endX = (cx + radius).coerceAtMost(bitmap.width - 1)
        val startY = (cy - radius).coerceAtLeast(0)
        val endY = (cy + radius).coerceAtMost(bitmap.height - 1)
        if (startX > endX || startY > endY) return Triple(0, 0, 0)

        val stepX = maxOf(1, (endX - startX) / 6)
        val stepY = maxOf(1, (endY - startY) / 6)

        var x = startX
        while (x <= endX) {
            var y = startY
            while (y <= endY) {
                val pixel = bitmap.getPixel(x, y)
                rSum += Color.red(pixel)
                gSum += Color.green(pixel)
                bSum += Color.blue(pixel)
                count++
                y += stepY
            }
            x += stepX
        }
        if (count == 0) count = 1
        return Triple((rSum / count).toInt(), (gSum / count).toInt(), (bSum / count).toInt())
    }

    /** Greedy single-pass clustering: assign to nearest existing cluster if close enough, else start a new one. */
    private fun clusterColors(
        samples: List<Triple<Int, Int, Int>>,
        maxClusters: Int,
        distanceThreshold: Double
    ): IntArray {
        val centers = mutableListOf<Triple<Int, Int, Int>>()
        val labels = IntArray(samples.size)

        for ((i, s) in samples.withIndex()) {
            var bestIdx = -1
            var bestDist = Double.MAX_VALUE
            for ((ci, c) in centers.withIndex()) {
                val d = colorDistance(s, c)
                if (d < bestDist) {
                    bestDist = d
                    bestIdx = ci
                }
            }
            labels[i] = when {
                bestIdx == -1 -> {
                    centers.add(s)
                    centers.size - 1
                }
                bestDist <= distanceThreshold -> bestIdx
                centers.size < maxClusters -> {
                    centers.add(s)
                    centers.size - 1
                }
                else -> bestIdx // out of cluster budget: fold into nearest
            }
        }
        return labels
    }

    private fun colorDistance(a: Triple<Int, Int, Int>, b: Triple<Int, Int, Int>): Double {
        val dr = (a.first - b.first).toDouble()
        val dg = (a.second - b.second).toDouble()
        val db = (a.third - b.third).toDouble()
        return sqrt(dr * dr + dg * dg + db * db)
    }
}
