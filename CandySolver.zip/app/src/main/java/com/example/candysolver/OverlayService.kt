package com.example.candysolver

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Two jobs, both via a WindowManager overlay (needs "draw over other apps"):
 *  - ACTION_CALIBRATE: a full-screen transparent view that captures two taps
 *    (top-left cell center, then bottom-right cell center) to set Calibration.
 *  - ACTION_SHOW_CONTROL: a small floating STOP button so the user has a
 *    one-tap kill switch without needing to return to the app.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_CALIBRATE = "com.example.candysolver.action.CALIBRATE"
        const val ACTION_SHOW_CONTROL = "com.example.candysolver.action.SHOW_CONTROL"
        const val ACTION_HIDE = "com.example.candysolver.action.HIDE"
    }

    private lateinit var windowManager: WindowManager
    private var calibrationView: View? = null
    private var controlView: View? = null
    private var firstTap: Pair<Int, Int>? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CALIBRATE -> showCalibrationOverlay()
            ACTION_SHOW_CONTROL -> showControlButton()
            ACTION_HIDE -> hideAll()
        }
        return START_NOT_STICKY
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showCalibrationOverlay() {
        removeCalibrationView()
        firstTap = null

        val instructions = TextView(this).apply {
            text = "Tap the CENTER of the TOP-LEFT tile"
            setBackgroundColor(0xAA000000.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            setPadding(28, 24, 28, 24)
        }

        val container = FrameLayout(this).apply {
            addView(
                instructions,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = 140
                    leftMargin = 40
                }
            )
        }

        container.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val x = event.rawX.toInt()
                val y = event.rawY.toInt()
                val first = firstTap
                if (first == null) {
                    firstTap = x to y
                    instructions.text = "Tap the CENTER of the BOTTOM-RIGHT tile"
                } else {
                    Calibration.left = minOf(first.first, x)
                    Calibration.top = minOf(first.second, y)
                    Calibration.right = maxOf(first.first, x)
                    Calibration.bottom = maxOf(first.second, y)
                    Calibration.save(this)
                    Toast.makeText(this, "Calibration saved (${Calibration.rows}x${Calibration.cols})", Toast.LENGTH_SHORT).show()
                    hideAll()
                }
            }
            true
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        calibrationView = container
        windowManager.addView(container, params)
    }

    private fun showControlButton() {
        removeControlView()
        val button = Button(this).apply {
            text = "STOP"
            setOnClickListener {
                SolverLoop.stop()
                hideAll()
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 120
        }
        controlView = button
        windowManager.addView(button, params)
    }

    private fun removeCalibrationView() {
        calibrationView?.let { runCatching { windowManager.removeView(it) } }
        calibrationView = null
    }

    private fun removeControlView() {
        controlView?.let { runCatching { windowManager.removeView(it) } }
        controlView = null
    }

    private fun hideAll() {
        removeCalibrationView()
        removeControlView()
        stopSelf()
    }

    override fun onDestroy() {
        removeCalibrationView()
        removeControlView()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
