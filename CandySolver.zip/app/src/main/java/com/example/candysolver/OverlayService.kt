package com.example.candysolver

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Floating UI for calibration and the in-game stop control.
 *
 * Calibration is automatic: the user positions the game so the board is
 * visible, taps "Detect Board" on a small floating panel, and GridDetector
 * analyzes the latest captured frame to guess the board's bounds and
 * row/column count. The result is shown as a highlighted rectangle plus
 * adjustable row/col counts so the user can confirm or nudge it before
 * saving -- this is a heuristic, not a guaranteed-correct detector, so the
 * confirm step is the safety net, and it can be re-run in a few taps every
 * time a new level changes the board.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_CALIBRATE = "com.example.candysolver.action.CALIBRATE"
        const val ACTION_SHOW_CONTROL = "com.example.candysolver.action.SHOW_CONTROL"
        const val ACTION_HIDE = "com.example.candysolver.action.HIDE"
    }

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var panelView: View? = null
    private var highlightView: View? = null
    private var controlView: View? = null

    private var pendingDetection: BoardDetection? = null
    private var pendingRows = 0
    private var pendingCols = 0

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CALIBRATE -> showDetectPanel()
            ACTION_SHOW_CONTROL -> showControlButton()
            ACTION_HIDE -> hideAll()
        }
        return START_NOT_STICKY
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun floatingParams(): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 140
        }

    // ---------- Step 1: floating "Detect Board" button ----------

    private fun showDetectPanel() {
        removePanel()
        removeHighlight()
        pendingDetection = null

        val button = Button(this).apply {
            text = "Detect Board"
            setOnClickListener { runDetection() }
        }
        panelView = button
        windowManager.addView(button, floatingParams())
        Toast.makeText(this, "Switch to the game, line up the board, then tap Detect Board", Toast.LENGTH_LONG).show()
    }

    private fun runDetection() {
        val frame = CaptureService.getLatestFrame()
        if (frame == null) {
            Toast.makeText(this, "No frame yet — grant screen capture first", Toast.LENGTH_SHORT).show()
            return
        }
        (panelView as? Button)?.apply { isEnabled = false; text = "Detecting…" }

        Thread {
            val result = try { GridDetector.detect(frame) } catch (t: Throwable) { null }
            mainHandler.post { onDetectionResult(result) }
        }.start()
    }

    private fun onDetectionResult(result: BoardDetection?) {
        if (result == null) {
            (panelView as? Button)?.apply { isEnabled = true; text = "Detect Board" }
            Toast.makeText(this, "Couldn't find a grid — reposition and try again", Toast.LENGTH_LONG).show()
            return
        }
        pendingDetection = result
        pendingRows = result.rows
        pendingCols = result.cols
        showHighlight(result)
        showConfirmPanel()
    }

    // ---------- Step 2: visual rectangle over the detected board ----------

    private fun showHighlight(detection: BoardDetection) {
        removeHighlight()
        val box = View(this).apply {
            background = GradientDrawable().apply {
                setStroke(6, Color.parseColor("#FF6F61"))
                setColor(Color.parseColor("#33FF6F61"))
            }
        }
        val params = WindowManager.LayoutParams(
            (detection.right - detection.left).coerceAtLeast(1),
            (detection.bottom - detection.top).coerceAtLeast(1),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = detection.left
            y = detection.top
        }
        highlightView = box
        windowManager.addView(box, params)
    }

    // ---------- Step 3: confirm / adjust rows & cols / retry / cancel ----------

    private fun showConfirmPanel() {
        removePanel()

        val label = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(8, 8, 8, 8)
        }
        fun refreshLabel() { label.text = "Detected board — ${pendingRows}\u00d7${pendingCols}" }
        refreshLabel()

        fun stepperRow(name: String, onMinus: () -> Unit, onPlus: () -> Unit): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(TextView(this@OverlayService).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    setPadding(4, 4, 12, 4)
                })
                addView(Button(this@OverlayService).apply {
                    text = "-"
                    setOnClickListener { onMinus(); refreshLabel() }
                })
                addView(Button(this@OverlayService).apply {
                    text = "+"
                    setOnClickListener { onPlus(); refreshLabel() }
                })
            }

        val rowStepper = stepperRow(
            "Rows",
            onMinus = { pendingRows = (pendingRows - 1).coerceAtLeast(3) },
            onPlus = { pendingRows = (pendingRows + 1).coerceAtMost(20) }
        )
        val colStepper = stepperRow(
            "Cols",
            onMinus = { pendingCols = (pendingCols - 1).coerceAtLeast(3) },
            onPlus = { pendingCols = (pendingCols + 1).coerceAtMost(20) }
        )

        val actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Button(this@OverlayService).apply {
                text = "Use"
                setOnClickListener { confirmDetection() }
            })
            addView(Button(this@OverlayService).apply {
                text = "Retry"
                setOnClickListener { showDetectPanel() }
            })
            addView(Button(this@OverlayService).apply {
                text = "Cancel"
                setOnClickListener { hideAll() }
            })
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC222222.toInt())
            setPadding(24, 16, 24, 16)
            addView(label)
            addView(rowStepper)
            addView(colStepper)
            addView(actionsRow)
        }

        panelView = panel
        windowManager.addView(panel, floatingParams())
    }

    private fun confirmDetection() {
        val d = pendingDetection ?: return
        Calibration.left = d.left
        Calibration.top = d.top
        Calibration.right = d.right
        Calibration.bottom = d.bottom
        Calibration.rows = pendingRows
        Calibration.cols = pendingCols
        Calibration.save(this)
        Toast.makeText(this, "Calibration saved: ${pendingRows}\u00d7${pendingCols}", Toast.LENGTH_SHORT).show()
        hideAll()
    }

    // ---------- Solving-in-progress stop control ----------

    private fun showControlButton() {
        removeControlView()
        val button = Button(this).apply {
            text = "STOP"
            setOnClickListener {
                SolverLoop.stop()
                hideAll()
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 120
        }
        controlView = button
        windowManager.addView(button, params)
    }

    // ---------- cleanup ----------

    private fun removePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
    }

    private fun removeHighlight() {
        highlightView?.let { runCatching { windowManager.removeView(it) } }
        highlightView = null
    }

    private fun removeControlView() {
        controlView?.let { runCatching { windowManager.removeView(it) } }
        controlView = null
    }

    private fun hideAll() {
        removePanel()
        removeHighlight()
        removeControlView()
        stopSelf()
    }

    override fun onDestroy() {
        removePanel()
        removeHighlight()
        removeControlView()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
