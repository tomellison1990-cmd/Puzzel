# Candy Solver

An Android app that watches a match-3 style game on screen, works out the
best move, and swipes it for you — automatically, in a loop.

## How it works

1. **Capture** — `MediaProjection` mirrors the screen into an `ImageReader`
   inside a foreground service (`CaptureService`), producing a fresh
   `Bitmap` on every frame.
2. **Calibrate (one-time)** — You tap the center of the top-left tile, then
   the center of the bottom-right tile, of the game's board. Combined with
   the row/column count you entered, this gives pixel coordinates for every
   cell (`Calibration`).
3. **Classify** — Each cell is sampled (a small patch, avoiding edges) and
   averaged to an RGB color; colors are greedily clustered into a handful
   of groups across the whole board, giving a tile-type ID per cell
   (`BoardAnalyzer`). This is deliberately cheap — no per-frame ML model —
   because color is enough to distinguish classic candy-style tiles.
4. **Solve** — Every legal adjacent swap is simulated and scored by the
   size of the match(es) it creates; the highest-scoring swap wins
   (`Solver`). For a 9×9 board that's ~150 candidate swaps, each an O(81)
   check — sub-millisecond, never the bottleneck.
5. **Act** — The winning swap is executed as a swipe gesture via an
   `AccessibilityService` (`SolverAccessibilityService`), since Android
   only allows synthetic touch input through that API.
6. **Loop** — `SolverLoop` waits for two consecutive captured frames to be
   near-identical (meaning the game's match/cascade animation has
   finished) before reading the board again, rather than sleeping a fixed
   delay — this is what keeps the loop fast without racing the animation.

## Project layout

```
CandySolver/
├── app/src/main/java/com/example/candysolver/
│   ├── MainActivity.kt                 setup screen: 4 one-time steps + start/stop
│   ├── Calibration.kt                  board bounds + row/col count (persisted)
│   ├── CaptureService.kt               MediaProjection foreground service
│   ├── OverlayService.kt               calibration taps + floating STOP button
│   ├── SolverAccessibilityService.kt   dispatches swipe gestures
│   ├── BoardAnalyzer.kt                pixels -> grid of tile-type IDs
│   ├── Solver.kt                       brute-force best-move search
│   └── SolverLoop.kt                   ties it all together
└── app/src/main/res/…                  layout, strings, accessibility config, icon
```

## Building it

1. Open the `CandySolver/` folder in Android Studio (Koala or newer).
   Let it sync — it'll fetch the Android Gradle Plugin, Kotlin, and the
   handful of AndroidX dependencies listed in `app/build.gradle.kts`. If
   Android Studio prompts to regenerate the Gradle wrapper jar, accept it.
2. Run on a physical device or emulator with **API 26+** (Android 8.0+).
   MediaProjection capture is unreliable on some emulator images — a real
   device is more reliable for this.
3. On first launch, walk through the 4 buttons in order:
   - **Enable Accessibility Service** — opens system settings; find
     "Candy Solver" and turn it on.
   - **Grant Screen Capture** — accepts the system's screen-recording
     permission dialog (this has to be re-granted each time the process
     restarts; that's an OS restriction, not a bug).
   - **Calibrate Grid** — enter rows/columns, tap Calibrate, grant
     "draw over other apps" if prompted, then switch to the game and tap
     the center of the top-left tile, then the center of the bottom-right
     tile.
   - **Start Solving** — switch to the game; a small floating STOP button
     appears so you can kill the loop without returning to this app.

## Known limitations / where to extend it

- **Color-based classification** assumes tiles are visually distinguishable
  by color. If your target game uses same-colored tiles with different
  icons, swap the sampling step in `BoardAnalyzer` for a shape/edge
  signature — nothing else in the pipeline needs to change.
- **No auto-detection of the grid** — calibration is manual (2 taps) by
  design, to stay reliable across arbitrary games without needing a CV
  model to find board edges.
- **Frame-diff stability check** samples a coarse grid of pixels; extremely
  slow or extremely fast game animations may need the sampling interval or
  similarity threshold in `SolverLoop.framesSimilar` tuned.
- **Cascades**: the solver picks the single best immediate swap. It does
  not look ahead through chain reactions — extending `Solver` to simulate
  one extra cascade level (apply gravity + refill with a placeholder tile,
  re-score) is a natural next step if you want it to prioritize combo
  setups.

## Please read before using

This automates gameplay by reading the screen and injecting touch events —
it doesn't hack the game's code or servers, but **it does violate the
terms of service of essentially every match-3 game** (Candy Crush's
included), which prohibit bots/automation. Realistic use is personal,
offline experimentation on a throwaway account — not something to run on
an account, leaderboard, or competitive mode you care about, and not
something to distribute or use against a live service.
